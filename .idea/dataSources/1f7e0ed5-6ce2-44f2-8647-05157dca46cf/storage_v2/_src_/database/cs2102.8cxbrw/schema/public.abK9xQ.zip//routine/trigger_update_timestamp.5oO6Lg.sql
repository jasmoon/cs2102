create function trigger_update_timestamp()
  returns trigger
language plpgsql
as $$
BEGIN
  NEW.last_modified = NOW();
  RETURN NEW;
END;
$$;

alter function trigger_update_timestamp()
  owner to cs2102;

