create function update_last_login(id integer)
  returns timestamp without time zone
language plpgsql
as $$
#variable_conflict use_variable
DECLARE
  currtime TIMESTAMP := NOW();
BEGIN
  UPDATE user_account SET last_login = currtime WHERE user_account.id = id;
  RETURN currtime;
END;
$$;

alter function update_last_login(integer)
  owner to cs2102;

